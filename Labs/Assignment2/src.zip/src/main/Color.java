/**
 * Represents the color of a chess piece.
 */
public enum Color {
  WHITE, BLACK;
}
